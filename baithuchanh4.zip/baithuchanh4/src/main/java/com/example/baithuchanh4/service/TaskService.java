package com.example.baithuchanh4.service;


import com.example.baithuchanh4.model.Task;
import com.example.baithuchanh4.model.User;
import com.example.baithuchanh4.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserService userService;

    @Autowired
    public TaskService(TaskRepository taskRepository, UserService userService) {
        this.taskRepository = taskRepository;
        this.userService = userService;
    }

    public List<Task> findAllTasks() {
        return taskRepository.findAll();
    }

    public Task createTask(Task newTask) {
        User assignedUser = userService.findUserById(newTask.getAssignedTo());

        if (assignedUser == null) {
            return null;
        }

        return taskRepository.save(newTask);
    }
}


