package com.example.baithuchanh4.controller;


import com.example.baithuchanh4.model.Task;
import com.example.baithuchanh4.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskService taskService;

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public ResponseEntity<List<Task>> findAllTasks(
            @RequestParam(required = false) String search
    ) {
        List<Task> tasks = taskService.findAllTasks();

        if (search != null && !search.trim().isEmpty()) {
            String keyword = search.toLowerCase();

            tasks = tasks.stream()
                    .filter(task -> task.getTitle().toLowerCase().contains(keyword))
                    .toList();
        }

        return ResponseEntity.ok(tasks);
    }

    @PostMapping
    public ResponseEntity<Task> createTask(@RequestBody Task newTask) {
        Task savedTask = taskService.createTask(newTask);

        if (savedTask == null) {
            return ResponseEntity.badRequest().build();
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(savedTask);
    }
}

