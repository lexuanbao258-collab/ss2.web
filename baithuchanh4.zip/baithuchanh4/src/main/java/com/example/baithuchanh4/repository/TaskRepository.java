package com.example.baithuchanh4.repository;


import com.example.baithuchanh4.model.Task;
import com.example.baithuchanh4.model.User;
import org.springframework.stereotype.Repository;


import java.util.ArrayList;
import java.util.List;

@Repository
public class TaskRepository {

    private final List<Task> tasks = new ArrayList<>();

    public TaskRepository() {
        tasks.add(new Task(1L, "Thiết kế RESTful API", "Thiết kế endpoint cho User và Task", "high", 1));
        tasks.add(new Task(2L, "Tạo model User", "Xây dựng class User", "medium", 1));
        tasks.add(new Task(3L, "Tạo model Task", "Xây dựng class Task", "medium", 2));
        tasks.add(new Task(4L, "Tạo UserRepository", "Hardcode danh sách user", "low", 2));
        tasks.add(new Task(5L, "Tạo TaskRepository", "Hardcode danh sách task", "high", 3));
        tasks.add(new Task(6L, "Tạo UserService", "Lấy dữ liệu user từ repository", "medium", 1));
        tasks.add(new Task(7L, "Tạo TaskService", "Lấy dữ liệu task từ repository", "medium", 2));
        tasks.add(new Task(8L, "Tạo UserController", "Tạo API lấy danh sách user", "high", 3));
        tasks.add(new Task(9L, "Tạo TaskController", "Tạo API lấy danh sách task", "high", 1));
        tasks.add(new Task(10L, "Kiểm tra Bean", "Chạy ứng dụng và kiểm tra lỗi khởi tạo Bean", "low", 2));
    }

    public List<Task> findAll() {
        return tasks;
    }

    public Task save(Task task) {
        tasks.add(task);
        return task;
    }
}

