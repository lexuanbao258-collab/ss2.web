package com.example.baithuchanh4.repository;
import com.example.baithuchanh4.model.User;
import org.springframework.stereotype.Repository;


import java.util.ArrayList;
import java.util.List;

@Repository
public class UserRepository {

    private final List<User> users = new ArrayList<>();

    public UserRepository() {
        users.add(new User(1L, "nguyenvana", "vana@example.com", "ADMIN"));
        users.add(new User(2L, "tranthib", "thib@example.com", "USER"));
        users.add(new User(3L, "levanc", "vanc@example.com", "MANAGER"));
    }

    public List<User> findAll() {
        return users;
    }

    public User findById(int id) {
        for (User user : users) {
            if (user.getId() == id) {
                return user;
            }
        }

        return null;
    }
}

