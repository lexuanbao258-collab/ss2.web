package com.example.baithuchanh4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Baithuchanh2Application {

    public static void main(String[] args) {
        SpringApplication.run(Baithuchanh2Application.class, args);
    }

}
