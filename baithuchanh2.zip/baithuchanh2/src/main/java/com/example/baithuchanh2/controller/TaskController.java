package com.example.baithuchanh2.controller;


import com.example.baithuchanh2.model.Task;
import com.example.baithuchanh2.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TaskController {

    private final TaskService taskService;

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping("/tasks")
    public List<Task> findAllTasks() {
        return taskService.findAllTasks();
    }
}

