package com.example.baithuchanh2.controller;


import com.example.baithuchanh2.model.Task;
import com.example.baithuchanh2.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import java.util.List;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskService taskService;

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping
    public ResponseEntity<List<Task>> findAllTasks(
            @RequestParam(required = false) String search
    ) {
        List<Task> tasks = taskService.findAllTasks();

        if (search != null && !search.trim().isEmpty()) {
            String keyword = search.toLowerCase();

            tasks = tasks.stream()
                    .filter(task -> task.getTitle()
                            .toLowerCase()
                            .contains(keyword))
                    .toList();
        }

        return ResponseEntity.ok(tasks);
    }
}
