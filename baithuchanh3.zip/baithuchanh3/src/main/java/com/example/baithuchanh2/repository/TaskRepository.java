package com.example.baithuchanh2.repository;


import com.example.baithuchanh2.model.Task;
import com.example.baithuchanh2.model.User;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class TaskRepository {

    private final List<Task> tasks = new ArrayList<>();

    public TaskRepository() {
        User user1 = new User(1L, "nguyenvana", "vana@example.com", "ADMIN");
        User user2 = new User(2L, "tranthib", "thib@example.com", "USER");
        User user3 = new User(3L, "levanc", "vanc@example.com", "MANAGER");

        tasks.add(new Task(1L, "Thiết kế RESTful API", "Thiết kế endpoint cho User và Task", "high", user1));
        tasks.add(new Task(2L, "Tạo model User", "Xây dựng class User", "medium", user1));
        tasks.add(new Task(3L, "Tạo model Task", "Xây dựng class Task", "medium", user2));
        tasks.add(new Task(4L, "Tạo UserRepository", "Hardcode danh sách user", "low", user2));
        tasks.add(new Task(5L, "Tạo TaskRepository", "Hardcode danh sách task", "high", user3));
        tasks.add(new Task(6L, "Tạo UserService", "Lấy dữ liệu user từ repository", "medium", user1));
        tasks.add(new Task(7L, "Tạo TaskService", "Lấy dữ liệu task từ repository", "medium", user2));
        tasks.add(new Task(8L, "Tạo UserController", "Tạo API lấy danh sách user", "high", user3));
        tasks.add(new Task(9L, "Tạo TaskController", "Tạo API lấy danh sách task", "high", user1));
        tasks.add(new Task(10L, "Kiểm tra Bean", "Chạy ứng dụng và kiểm tra lỗi khởi tạo Bean", "low", user2));
    }

    public List<Task> findAll() {
        return tasks;
    }
}
